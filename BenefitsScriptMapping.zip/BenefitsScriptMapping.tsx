import { useState, useCallback } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────

type PlanKey = "inn" | "oon" | "innoon";
type ScriptKey = "copay" | "deductible" | "coinsurance";

interface MemberInfo {
  memberId: string;
  groupNo: string;
  groupName: string;
  dateOfService: string;
  planName: string;
  networkPl: string;
}

interface CopayData {
  network: string;
  copayAmt: string;
  periodType: string;
  oopPaid: string;
  oopTotal: string;
  periodType2: string;
}

interface DeductibleData {
  network: string;
  planPeriod: string;
  dedType: string;
  dedPaid: string;
  dedTotal: string;
  coinsPct: string;
  memberPct: string;
  oopType: string;
  oopPaid: string;
  oopTotal: string;
  period3: string;
}

interface CoinsuranceData {
  network: string;
  planPeriod: string;
  dedType: string;
  dedPaid: string;
  coinsPct: string;
  coinsAmt: string;
  memberPays: string;
  coinsMaxType: string;
  coinsMaxPaid: string;
  coinsMaxTotal: string;
  period3: string;
}

type ScriptData = {
  copay: Record<PlanKey, CopayData>;
  deductible: Record<PlanKey, DeductibleData>;
  coinsurance: Record<PlanKey, CoinsuranceData>;
};

// ─── Initial Mock Data ────────────────────────────────────────────────────────

const initialData: ScriptData = {
  copay: {
    inn: {
      network: "INN", copayAmt: "20", periodType: "Calendar Year",
      oopPaid: "1,500", oopTotal: "3,000", periodType2: "Calendar Year",
    },
    oon: {
      network: "OON", copayAmt: "50", periodType: "Calendar Year",
      oopPaid: "2,800", oopTotal: "6,000", periodType2: "Plan Year",
    },
    innoon: {
      network: "INN/OON", copayAmt: "30", periodType: "Plan Year",
      oopPaid: "2,200", oopTotal: "5,000", periodType2: "Calendar Year",
    },
  },
  deductible: {
    inn: {
      network: "INN", planPeriod: "Calendar Year", dedType: "Individual",
      dedPaid: "400.00", dedTotal: "2,000", coinsPct: "80%", memberPct: "20%",
      oopType: "Individual/Family", oopPaid: "1,181.13", oopTotal: "5,300", period3: "Calendar Year",
    },
    oon: {
      network: "OON", planPeriod: "Plan Year", dedType: "Individual",
      dedPaid: "800.00", dedTotal: "4,000", coinsPct: "70%", memberPct: "30%",
      oopType: "Individual/Family", oopPaid: "2,500.00", oopTotal: "10,600", period3: "Plan Year",
    },
    innoon: {
      network: "INN/OON", planPeriod: "Calendar Year", dedType: "Individual/Family",
      dedPaid: "600.00", dedTotal: "3,000", coinsPct: "75%", memberPct: "25%",
      oopType: "Individual/Family", oopPaid: "1,800.00", oopTotal: "8,000", period3: "Calendar Year",
    },
  },
  coinsurance: {
    inn: {
      network: "INN", planPeriod: "Calendar Year", dedType: "Individual/Family",
      dedPaid: "400.00", coinsPct: "80%", coinsAmt: "the Allowable Amount",
      memberPays: "20%", coinsMaxType: "Individual/Family",
      coinsMaxPaid: "500.00", coinsMaxTotal: "2,000", period3: "Calendar Year",
    },
    oon: {
      network: "OON", planPeriod: "Plan Year", dedType: "Individual/Family",
      dedPaid: "800.00", coinsPct: "70%", coinsAmt: "the Allowable Amount",
      memberPays: "30%", coinsMaxType: "Individual/Family",
      coinsMaxPaid: "1,200.00", coinsMaxTotal: "4,000", period3: "Plan Year",
    },
    innoon: {
      network: "INN/OON", planPeriod: "Calendar Year", dedType: "Individual/Family",
      dedPaid: "600.00", coinsPct: "75%", coinsAmt: "the Allowable Amount",
      memberPays: "25%", coinsMaxType: "Individual/Family",
      coinsMaxPaid: "900.00", coinsMaxTotal: "3,000", period3: "Calendar Year",
    },
  },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function calcRemaining(paid: string, total: string): string {
  const p = parseFloat(paid.replace(/,/g, "")) || 0;
  const t = parseFloat(total.replace(/,/g, "")) || 0;
  return Math.max(0, t - p).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

// ─── Sub-components ───────────────────────────────────────────────────────────

interface InlineInputProps {
  value: string;
  width?: number;
  onChange: (v: string) => void;
}

function InlineInput({ value, width = 70, onChange }: InlineInputProps) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{
        border: "none",
        borderBottom: "1.5px solid #378ADD",
        background: "transparent",
        fontSize: 13,
        color: "#0C447C",
        padding: "1px 3px",
        minWidth: width,
        outline: "none",
        fontFamily: "inherit",
        textAlign: "center",
      }}
    />
  );
}

interface InlineSelectProps {
  value: string;
  options: string[];
  onChange: (v: string) => void;
}

function InlineSelect({ value, options, onChange }: InlineSelectProps) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{
        border: "none",
        borderBottom: "1.5px solid #D85A30",
        background: "transparent",
        fontSize: 13,
        color: "#712B13",
        padding: "1px 2px",
        outline: "none",
        cursor: "pointer",
        fontFamily: "inherit",
      }}
    >
      {options.map((o) => (
        <option key={o}>{o}</option>
      ))}
    </select>
  );
}

const PERIOD_OPTS = ["Calendar Year", "Plan Year"];
const NETWORK_OPTS = ["INN", "OON", "INN/OON"];

interface ConditionalBlockProps {
  label: string;
  children: React.ReactNode;
}

function ConditionalBlock({ label, children }: ConditionalBlockProps) {
  return (
    <div
      style={{
        marginTop: 16,
        padding: "10px 14px",
        background: "#f5f5f3",
        borderLeft: "3px solid rgba(0,0,0,0.18)",
        borderRadius: "0 8px 8px 0",
        lineHeight: 2,
        fontSize: 13,
      }}
    >
      <div
        style={{
          fontSize: 11,
          fontWeight: 500,
          color: "#888780",
          textTransform: "uppercase",
          letterSpacing: "0.05em",
          marginBottom: 8,
        }}
      >
        {label}
      </div>
      {children}
    </div>
  );
}

// ─── Script Renderers ─────────────────────────────────────────────────────────

interface CopayScriptProps {
  data: CopayData;
  onChange: (field: keyof CopayData, value: string) => void;
}

function CopayScript({ data, onChange }: CopayScriptProps) {
  return (
    <div style={{ fontSize: 13.5, lineHeight: 2, color: "#1a1a18" }}>
      You're currently active and eligible on a{" "}
      <InlineSelect value={data.periodType} options={PERIOD_OPTS} onChange={(v) => onChange("periodType", v)} />.
      {" "}Your benefits are subject to the{" "}
      <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
        <InlineSelect value={data.network} options={NETWORK_OPTS} onChange={(v) => onChange("network", v)} />
      </span>{" "}
      $<InlineInput value={data.copayAmt} width={55} onChange={(v) => onChange("copayAmt", v)} /> copay.

      <ConditionalBlock label="If copay applies toward the plan's out-of-pocket maximum, include the following:">
        In-network copayments will apply to the members out-of-pocket maximum. Currently the member has{" "}
        <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
          paid $<InlineInput value={data.oopPaid} width={80} onChange={(v) => onChange("oopPaid", v)} />
        </span>{" "}
        towards the{" "}
        <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
          Individual/Family
        </span>{" "}
        $<InlineInput value={data.oopTotal} width={80} onChange={(v) => onChange("oopTotal", v)} /> out-of-pocket maximum.
        Once the out-of-pocket maximum is reached then the plan will pay 100% of the allowable amount for the remainder of the{" "}
        <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
          <InlineSelect value={data.periodType2} options={PERIOD_OPTS} onChange={(v) => onChange("periodType2", v)} />{" "}
          (Calendar Year/Plan Year)
        </span>.
      </ConditionalBlock>
    </div>
  );
}

interface DeductibleScriptProps {
  data: DeductibleData;
  onChange: (field: keyof DeductibleData, value: string) => void;
}

function DeductibleScript({ data, onChange }: DeductibleScriptProps) {
  return (
    <div style={{ fontSize: 13.5, lineHeight: 2, color: "#1a1a18" }}>
      You're currently active and eligible on a{" "}
      <InlineSelect value={data.planPeriod} options={PERIOD_OPTS} onChange={(v) => onChange("planPeriod", v)} />.
      {" "}Your benefits are subject to the{" "}
      <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
        <InlineSelect value={data.network} options={NETWORK_OPTS} onChange={(v) => onChange("network", v)} />
      </span>{" "}
      Deductible and Out-of-Pocket Maximum. The member has an{" "}
      <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
        <InlineInput value={data.dedType} width={130} onChange={(v) => onChange("dedType", v)} />
      </span>{" "}
      Deductible of $<InlineInput value={data.dedPaid} width={80} onChange={(v) => onChange("dedPaid", v)} />.
      {" "}Once the{" "}
      <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>Deductible</span>{" "}
      is met, the plan will pay{" "}
      <InlineInput value={data.coinsPct} width={55} onChange={(v) => onChange("coinsPct", v)} />{" "}
      of the Allowable Amount, and the member will pay{" "}
      <InlineInput value={data.memberPct} width={55} onChange={(v) => onChange("memberPct", v)} />{" "}
      of the Allowable Amount.

      <ConditionalBlock label="Out-of-pocket maximum progress">
        Currently the member has paid $
        <InlineInput value={data.oopPaid} width={85} onChange={(v) => onChange("oopPaid", v)} />{" "}
        towards the{" "}
        <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
          <InlineInput value={data.oopType} width={140} onChange={(v) => onChange("oopType", v)} />
        </span>{" "}
        $<InlineInput value={data.oopTotal} width={80} onChange={(v) => onChange("oopTotal", v)} /> Out-of-Pocket Maximum.
        Once the Out-of-Pocket Maximum is reached, the plan will then pay 100% of the Allowable Amount for the remainder of the{" "}
        <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
          <InlineSelect value={data.period3} options={PERIOD_OPTS} onChange={(v) => onChange("period3", v)} />
        </span>.
      </ConditionalBlock>
    </div>
  );
}

interface CoinsuranceScriptProps {
  data: CoinsuranceData;
  onChange: (field: keyof CoinsuranceData, value: string) => void;
}

function CoinsuranceScript({ data, onChange }: CoinsuranceScriptProps) {
  return (
    <div style={{ fontSize: 13.5, lineHeight: 2, color: "#1a1a18" }}>
      You're currently active and eligible on a{" "}
      <InlineSelect value={data.planPeriod} options={PERIOD_OPTS} onChange={(v) => onChange("planPeriod", v)} />.
      {" "}Your benefits are subject to the{" "}
      <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
        <InlineSelect value={data.network} options={NETWORK_OPTS} onChange={(v) => onChange("network", v)} />
      </span>{" "}
      Deductible and Coinsurance Maximum. The member has an{" "}
      <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
        <InlineInput value={data.dedType} width={130} onChange={(v) => onChange("dedType", v)} />
      </span>{" "}
      Deductible of $<InlineInput value={data.dedPaid} width={80} onChange={(v) => onChange("dedPaid", v)} />.
      {" "}Once the{" "}
      <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>Deductible</span>{" "}
      is met, the plan will pay{" "}
      <InlineInput value={data.coinsPct} width={55} onChange={(v) => onChange("coinsPct", v)} />{" "}
      of{" "}
      <InlineInput value={data.coinsAmt} width={160} onChange={(v) => onChange("coinsAmt", v)} />,
      up to the Coinsurance Maximum, and the member will pay{" "}
      <InlineInput value={data.memberPays} width={55} onChange={(v) => onChange("memberPays", v)} />{" "}
      of the Allowable Amount.

      <ConditionalBlock label="Coinsurance maximum progress">
        Currently the member has paid $
        <InlineInput value={data.coinsMaxPaid} width={85} onChange={(v) => onChange("coinsMaxPaid", v)} />{" "}
        towards the{" "}
        <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
          <InlineInput value={data.coinsMaxType} width={140} onChange={(v) => onChange("coinsMaxType", v)} />
        </span>{" "}
        Deductible and Coinsurance Maximum of $
        <InlineInput value={data.coinsMaxTotal} width={80} onChange={(v) => onChange("coinsMaxTotal", v)} />.
        Once the Coinsurance Maximum is reached, the plan will then pay 100% of the Allowable Amount for the remainder of the{" "}
        <span style={{ fontStyle: "italic", textDecoration: "line-through", color: "#888780" }}>
          <InlineSelect value={data.period3} options={PERIOD_OPTS} onChange={(v) => onChange("period3", v)} />
        </span>.
      </ConditionalBlock>

      <div
        style={{
          fontSize: 11,
          color: "#888780",
          marginTop: 16,
          paddingTop: 12,
          borderTop: "0.5px solid rgba(0,0,0,0.1)",
          fontStyle: "italic",
        }}
      >
        ** Be careful when quoting OON Coinsurance Max details; some plans have no OON Coinsurance Max, but pays at a coinsurance %.
      </div>
    </div>
  );
}

// ─── Summary Cards ────────────────────────────────────────────────────────────

interface SummaryCardProps {
  label: string;
  value: string;
  sub: string;
}

function SummaryCard({ label, value, sub }: SummaryCardProps) {
  return (
    <div
      style={{
        background: "#f5f5f3",
        borderRadius: 8,
        padding: "10px 14px",
        textAlign: "center",
        flex: "1 1 120px",
      }}
    >
      <div style={{ fontSize: 11, color: "#888780", textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 4 }}>
        {label}
      </div>
      <div style={{ fontSize: 16, fontWeight: 500, color: "#1a1a18" }}>{value}</div>
      <div style={{ fontSize: 11, color: "#5f5e5a", marginTop: 2 }}>{sub}</div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function BenefitsScriptMapping() {
  const [currentScript, setCurrentScript] = useState<ScriptKey>("copay");
  const [currentPlan, setCurrentPlan] = useState<PlanKey>("inn");
  const [memberInfo, setMemberInfo] = useState<MemberInfo>({
    memberId: "8014441589",
    groupNo: "1037844",
    groupName: "Starbucks Corp.",
    dateOfService: "2026-04-20",
    planName: "M-Heritage Prime",
    networkPl: "5222",
  });
  const [data, setData] = useState<ScriptData>(initialData);
  const [toastVisible, setToastVisible] = useState(false);

  const updateMember = (field: keyof MemberInfo, value: string) =>
    setMemberInfo((prev) => ({ ...prev, [field]: value }));

  const updateScriptField = useCallback(
    <K extends ScriptKey>(script: K, plan: PlanKey, field: string, value: string) => {
      setData((prev) => ({
        ...prev,
        [script]: {
          ...prev[script],
          [plan]: {
            ...(prev[script][plan] as object),
            [field]: value,
          },
        },
      }));
    },
    []
  );

  const copayData = data.copay[currentPlan];
  const dedData = data.deductible[currentPlan];
  const coinsData = data.coinsurance[currentPlan];

  const summaryCards = (): SummaryCardProps[] => {
    if (currentScript === "copay") {
      return [
        { label: "Copay Amount", value: `$${copayData.copayAmt}`, sub: copayData.network },
        { label: "OOP Paid", value: `$${copayData.oopPaid}`, sub: "Member progress" },
        { label: "OOP Maximum", value: `$${copayData.oopTotal}`, sub: copayData.periodType },
        { label: "Remaining OOP", value: `$${calcRemaining(copayData.oopPaid, copayData.oopTotal)}`, sub: "Until 100% coverage" },
      ];
    }
    if (currentScript === "deductible") {
      return [
        { label: "Deductible Paid", value: `$${dedData.dedPaid}`, sub: dedData.dedType },
        { label: "Deductible Total", value: `$${dedData.dedTotal}`, sub: dedData.planPeriod },
        { label: "OOP Paid", value: `$${dedData.oopPaid}`, sub: "Member progress" },
        { label: "OOP Maximum", value: `$${dedData.oopTotal}`, sub: dedData.oopType },
      ];
    }
    return [
      { label: "Deductible Paid", value: `$${coinsData.dedPaid}`, sub: coinsData.dedType },
      { label: "Coins. Rate", value: coinsData.coinsPct, sub: "Plan pays" },
      { label: "Coins. Max Paid", value: `$${coinsData.coinsMaxPaid}`, sub: "Member progress" },
      { label: "Coins. Maximum", value: `$${coinsData.coinsMaxTotal}`, sub: coinsData.coinsMaxType },
    ];
  };

  const handleCopy = () => {
    const texts: string[] = [];
    document.querySelectorAll("[data-script-body]").forEach((el) => {
      texts.push((el as HTMLElement).innerText.trim());
    });
    navigator.clipboard.writeText(texts.join("\n")).catch(() => {});
    setToastVisible(true);
    setTimeout(() => setToastVisible(false), 2000);
  };

  const scriptTabs: { key: ScriptKey; label: string }[] = [
    { key: "copay", label: "Copayment" },
    { key: "deductible", label: "Deductible / OOP" },
    { key: "coinsurance", label: "Deductible / Coinsurance Max" },
  ];

  const planTabs: { key: PlanKey; label: string; color: string; bg: string; border: string }[] = [
    { key: "inn", label: "INN", color: "#085041", bg: "#E1F5EE", border: "#1D9E75" },
    { key: "oon", label: "OON", color: "#712B13", bg: "#FAECE7", border: "#D85A30" },
    { key: "innoon", label: "INN/OON", color: "#3C3489", bg: "#EEEDFE", border: "#534AB7" },
  ];

  const memberFields: { key: keyof MemberInfo; label: string; type?: string }[] = [
    { key: "memberId", label: "Member ID" },
    { key: "groupNo", label: "Group No." },
    { key: "groupName", label: "Group Name" },
    { key: "dateOfService", label: "Date of Service", type: "date" },
    { key: "planName", label: "Plan Name" },
    { key: "networkPl", label: "Network PL#" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#eeece6", padding: "2rem 1rem", fontFamily: "'DM Sans', 'Segoe UI', sans-serif" }}>
      <div style={{ maxWidth: 860, margin: "0 auto" }}>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: "1.5rem" }}>
          <h1 style={{ fontSize: 18, fontWeight: 500, color: "#1a1a18" }}>Script field mapping</h1>
          <span style={{ fontSize: 13, color: "#5f5e5a" }}>— benefits quoting tool</span>
        </div>

        {/* Member Info Bar */}
        <div
          style={{
            background: "#fff",
            border: "0.5px solid rgba(0,0,0,0.12)",
            borderRadius: 12,
            padding: "1rem 1.25rem",
            marginBottom: "1.25rem",
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))",
            gap: 12,
          }}
        >
          {memberFields.map(({ key, label, type }) => (
            <div key={key}>
              <label style={{ display: "block", fontSize: 11, color: "#888780", textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 4 }}>
                {label}
              </label>
              <input
                type={type || "text"}
                value={memberInfo[key]}
                onChange={(e) => updateMember(key, e.target.value)}
                style={{
                  width: "100%",
                  border: "0.5px solid rgba(0,0,0,0.22)",
                  borderRadius: 8,
                  padding: "5px 8px",
                  fontSize: 13,
                  background: "#f5f5f3",
                  color: "#1a1a18",
                  outline: "none",
                  fontFamily: "inherit",
                }}
              />
            </div>
          ))}
        </div>

        {/* Script Type Tabs */}
        <div
          style={{
            display: "flex",
            gap: 0,
            background: "#fff",
            borderRadius: "12px 12px 0 0",
            border: "0.5px solid rgba(0,0,0,0.12)",
            borderBottom: "none",
            padding: "0 1rem",
          }}
        >
          {scriptTabs.map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setCurrentScript(key)}
              style={{
                padding: "10px 16px",
                border: "none",
                background: "none",
                cursor: "pointer",
                fontSize: 13,
                color: currentScript === key ? "#1a1a18" : "#888780",
                borderBottom: currentScript === key ? "2px solid #1a1a18" : "2px solid transparent",
                fontWeight: currentScript === key ? 500 : 400,
                fontFamily: "inherit",
                transition: "color 0.15s",
                marginBottom: -0.5,
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Plan Tabs */}
        <div style={{ display: "flex", gap: 6, margin: "12px 0" }}>
          {planTabs.map(({ key, label, color, bg, border }) => {
            const active = currentPlan === key;
            return (
              <button
                key={key}
                onClick={() => setCurrentPlan(key)}
                style={{
                  padding: "6px 18px",
                  border: `0.5px solid ${active ? border : "rgba(0,0,0,0.22)"}`,
                  borderRadius: 8,
                  background: active ? bg : "#fff",
                  cursor: "pointer",
                  fontSize: 12,
                  color: active ? color : "#888780",
                  fontFamily: "inherit",
                  fontWeight: 500,
                  transition: "all 0.15s",
                }}
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* Script Card */}
        <div
          style={{
            background: "#fff",
            border: "0.5px solid rgba(0,0,0,0.12)",
            borderRadius: "0 0 12px 12px",
            padding: "1.5rem",
            marginBottom: "1rem",
          }}
        >
          {/* Card Header */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1.25rem" }}>
            <div style={{ flex: 1 }} />
            <div style={{ fontSize: 14, fontWeight: 500, textDecoration: "underline", flex: 1, textAlign: "center" }}>
              {currentScript === "copay" && "Copayment"}
              {currentScript === "deductible" && "Deductible/OOP Plans"}
              {currentScript === "coinsurance" && "Deductible/Coinsurance Maximum Plans"}
            </div>
            <div style={{ flex: 1, textAlign: "right" }}>
              <button
                onClick={handleCopy}
                style={{
                  fontSize: 11,
                  padding: "4px 12px",
                  border: "0.5px solid rgba(0,0,0,0.22)",
                  borderRadius: 8,
                  background: "#f5f5f3",
                  cursor: "pointer",
                  color: "#5f5e5a",
                  fontFamily: "inherit",
                }}
              >
                Copy script ↗
              </button>
            </div>
          </div>

          {/* Script Body */}
          <div data-script-body>
            {currentScript === "copay" && (
              <CopayScript
                data={copayData}
                onChange={(field, value) => updateScriptField("copay", currentPlan, field, value)}
              />
            )}
            {currentScript === "deductible" && (
              <DeductibleScript
                data={dedData}
                onChange={(field, value) => updateScriptField("deductible", currentPlan, field, value)}
              />
            )}
            {currentScript === "coinsurance" && (
              <CoinsuranceScript
                data={coinsData}
                onChange={(field, value) => updateScriptField("coinsurance", currentPlan, field, value)}
              />
            )}
          </div>
        </div>

        {/* Summary Bar */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
          {summaryCards().map((card) => (
            <SummaryCard key={card.label} {...card} />
          ))}
        </div>
      </div>

      {/* Toast */}
      <div
        style={{
          position: "fixed",
          bottom: 24,
          right: 24,
          background: "#1a1a18",
          color: "#fff",
          padding: "8px 16px",
          borderRadius: 8,
          fontSize: 13,
          opacity: toastVisible ? 1 : 0,
          transform: toastVisible ? "translateY(0)" : "translateY(8px)",
          transition: "all 0.2s",
          pointerEvents: "none",
          zIndex: 100,
        }}
      >
        Script copied to clipboard
      </div>
    </div>
  );
}
