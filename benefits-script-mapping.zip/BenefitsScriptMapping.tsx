import { useState, useCallback } from "react";
import "./benefitsScript.styles.css";

// ─── Types ────────────────────────────────────────────────────────────────────

type PlanKey = "inn" | "oon" | "innoon";
type ScriptKey = "copay" | "deductible" | "coinsurance" | "preventive";

// Combined dropdown key: "scriptKey|planKey"
type DropdownKey = string;

interface ScriptField {
  key: string;
  label?: string;
  type: "input" | "select" | "static";
  options?: string[];
  width?: number;
  strikethrough?: boolean;
}

interface ScriptSegment {
  text?: string;
  field?: ScriptField;
}

interface ConditionalSection {
  label: string;
  segments: ScriptSegment[];
}

interface ScriptTemplate {
  title: string;
  segments: ScriptSegment[];
  conditional?: ConditionalSection;
  note?: string;
}

// ─── Dropdown Options ─────────────────────────────────────────────────────────

interface DropdownOption {
  value: DropdownKey;
  label: string;
  scriptKey: ScriptKey;
  planKey: PlanKey | null;
}

const DROPDOWN_OPTIONS: DropdownOption[] = [
  { value: "deductible|inn",    label: "Deductible/OOP Plans - INN",                    scriptKey: "deductible",   planKey: "inn"    },
  { value: "deductible|oon",    label: "Deductible/OOP Plans - OON",                    scriptKey: "deductible",   planKey: "oon"    },
  { value: "deductible|innoon", label: "Deductible/OOP Plans - INN/OON",                scriptKey: "deductible",   planKey: "innoon" },
  { value: "coinsurance|inn",   label: "Deductible/Coinsurance Maximum plans - INN",    scriptKey: "coinsurance",  planKey: "inn"    },
  { value: "coinsurance|oon",   label: "Deductible/Coinsurance Maximum plans - OON",    scriptKey: "coinsurance",  planKey: "oon"    },
  { value: "coinsurance|innoon",label: "Deductible/Coinsurance Maximum plans - INN/OON",scriptKey: "coinsurance",  planKey: "innoon" },
  { value: "copay|inn",         label: "Copayment script - INN",                        scriptKey: "copay",        planKey: "inn"    },
  { value: "copay|oon",         label: "Copayment script - OON",                        scriptKey: "copay",        planKey: "oon"    },
  { value: "copay|innoon",      label: "Copayment script - INN/OON",                    scriptKey: "copay",        planKey: "innoon" },
  { value: "preventive|inn",    label: "Preventive",                                    scriptKey: "preventive",   planKey: "inn"    },
];

// ─── Initial Mock Data ────────────────────────────────────────────────────────

type DataStore = Record<DropdownKey, Record<string, string>>;

const initialData: DataStore = {
  "copay|inn": {
    network: "INN", copayAmt: "20", periodType: "Calendar Year",
    oopPaid: "1,500", oopTotal: "3,000", periodType2: "Calendar Year",
  },
  "copay|oon": {
    network: "OON", copayAmt: "50", periodType: "Calendar Year",
    oopPaid: "2,800", oopTotal: "6,000", periodType2: "Plan Year",
  },
  "copay|innoon": {
    network: "INN/OON", copayAmt: "30", periodType: "Plan Year",
    oopPaid: "2,200", oopTotal: "5,000", periodType2: "Calendar Year",
  },
  "deductible|inn": {
    network: "INN", planPeriod: "Calendar Year", dedType: "Individual",
    dedPaid: "400.00", dedTotal: "2,000", coinsPct: "80%", memberPct: "20%",
    oopType: "Individual/Family", oopPaid: "1,181.13", oopTotal: "5,300", period3: "Calendar Year",
  },
  "deductible|oon": {
    network: "OON", planPeriod: "Plan Year", dedType: "Individual",
    dedPaid: "800.00", dedTotal: "4,000", coinsPct: "70%", memberPct: "30%",
    oopType: "Individual/Family", oopPaid: "2,500.00", oopTotal: "10,600", period3: "Plan Year",
  },
  "deductible|innoon": {
    network: "INN/OON", planPeriod: "Calendar Year", dedType: "Individual/Family",
    dedPaid: "600.00", dedTotal: "3,000", coinsPct: "75%", memberPct: "25%",
    oopType: "Individual/Family", oopPaid: "1,800.00", oopTotal: "8,000", period3: "Calendar Year",
  },
  "coinsurance|inn": {
    network: "INN", planPeriod: "Calendar Year", dedType: "Individual/Family",
    dedPaid: "400.00", coinsPct: "80%", coinsAmt: "the Allowable Amount",
    memberPays: "20%", coinsMaxType: "Individual/Family",
    coinsMaxPaid: "500.00", coinsMaxTotal: "2,000", period3: "Calendar Year",
  },
  "coinsurance|oon": {
    network: "OON", planPeriod: "Plan Year", dedType: "Individual/Family",
    dedPaid: "800.00", coinsPct: "70%", coinsAmt: "the Allowable Amount",
    memberPays: "30%", coinsMaxType: "Individual/Family",
    coinsMaxPaid: "1,200.00", coinsMaxTotal: "4,000", period3: "Plan Year",
  },
  "coinsurance|innoon": {
    network: "INN/OON", planPeriod: "Calendar Year", dedType: "Individual/Family",
    dedPaid: "600.00", coinsPct: "75%", coinsAmt: "the Allowable Amount",
    memberPays: "25%", coinsMaxType: "Individual/Family",
    coinsMaxPaid: "900.00", coinsMaxTotal: "3,000", period3: "Calendar Year",
  },
  "preventive|inn": {
    periodType: "Calendar Year", network: "INN",
  },
};

// ─── Dynamic Script Templates ─────────────────────────────────────────────────

const PERIOD_OPTS = ["Calendar Year", "Plan Year"];
const NETWORK_OPTS = ["INN", "OON", "INN/OON"];

function getTemplate(scriptKey: ScriptKey): ScriptTemplate {
  switch (scriptKey) {
    case "copay":
      return {
        title: "Copayment",
        segments: [
          { text: "You're currently active and eligible on a " },
          { field: { key: "periodType", type: "select", options: PERIOD_OPTS } },
          { text: ". Your benefits are subject to the " },
          { field: { key: "network", type: "select", options: NETWORK_OPTS, strikethrough: true } },
          { text: " $" },
          { field: { key: "copayAmt", type: "input", width: 55 } },
          { text: " copay." },
        ],
        conditional: {
          label: "If copay applies toward the plan's out-of-pocket maximum, include the following:",
          segments: [
            { text: "In-network copayments will apply to the members out-of-pocket maximum. Currently the member has " },
            { field: { key: "oopPaid", type: "input", width: 80, strikethrough: true, label: "paid $" } },
            { text: " towards the " },
            { field: { key: "oopType", type: "static" } },
            { text: " $" },
            { field: { key: "oopTotal", type: "input", width: 80 } },
            { text: " out-of-pocket maximum. Once the out-of-pocket maximum is reached then the plan will pay 100% of the allowable amount for the remainder of the " },
            { field: { key: "periodType2", type: "select", options: PERIOD_OPTS, strikethrough: true } },
            { text: "." },
          ],
        },
      };

    case "deductible":
      return {
        title: "Deductible/OOP Plans",
        segments: [
          { text: "You're currently active and eligible on a " },
          { field: { key: "planPeriod", type: "select", options: PERIOD_OPTS } },
          { text: ". Your benefits are subject to the " },
          { field: { key: "network", type: "select", options: NETWORK_OPTS, strikethrough: true } },
          { text: " Deductible and Out-of-Pocket Maximum. The member has an " },
          { field: { key: "dedType", type: "input", width: 130, strikethrough: true } },
          { text: " Deductible of $" },
          { field: { key: "dedPaid", type: "input", width: 80 } },
          { text: ". Once the " },
          { field: { key: "deductibleStatic", type: "static" } },
          { text: " is met, the plan will pay " },
          { field: { key: "coinsPct", type: "input", width: 55 } },
          { text: " of the Allowable Amount, and the member will pay " },
          { field: { key: "memberPct", type: "input", width: 55 } },
          { text: " of the Allowable Amount." },
        ],
        conditional: {
          label: "Out-of-pocket maximum progress",
          segments: [
            { text: "Currently the member has paid $" },
            { field: { key: "oopPaid", type: "input", width: 85 } },
            { text: " towards the " },
            { field: { key: "oopType", type: "input", width: 140, strikethrough: true } },
            { text: " $" },
            { field: { key: "oopTotal", type: "input", width: 80 } },
            { text: " Out-of-Pocket Maximum. Once the Out-of-Pocket Maximum is reached, the plan will then pay 100% of the Allowable Amount for the remainder of the " },
            { field: { key: "period3", type: "select", options: PERIOD_OPTS, strikethrough: true } },
            { text: "." },
          ],
        },
      };

    case "coinsurance":
      return {
        title: "Deductible/Coinsurance Maximum Plans",
        segments: [
          { text: "You're currently active and eligible on a " },
          { field: { key: "planPeriod", type: "select", options: PERIOD_OPTS } },
          { text: ". Your benefits are subject to the " },
          { field: { key: "network", type: "select", options: NETWORK_OPTS, strikethrough: true } },
          { text: " Deductible and Coinsurance Maximum. The member has an " },
          { field: { key: "dedType", type: "input", width: 130, strikethrough: true } },
          { text: " Deductible of $" },
          { field: { key: "dedPaid", type: "input", width: 80 } },
          { text: ". Once the " },
          { field: { key: "deductibleStatic", type: "static" } },
          { text: " is met, the plan will pay " },
          { field: { key: "coinsPct", type: "input", width: 55 } },
          { text: " of " },
          { field: { key: "coinsAmt", type: "input", width: 160 } },
          { text: ", up to the Coinsurance Maximum, and the member will pay " },
          { field: { key: "memberPays", type: "input", width: 55 } },
          { text: " of the Allowable Amount." },
        ],
        conditional: {
          label: "Coinsurance maximum progress",
          segments: [
            { text: "Currently the member has paid $" },
            { field: { key: "coinsMaxPaid", type: "input", width: 85 } },
            { text: " towards the " },
            { field: { key: "coinsMaxType", type: "input", width: 140, strikethrough: true } },
            { text: " Deductible and Coinsurance Maximum of $" },
            { field: { key: "coinsMaxTotal", type: "input", width: 80 } },
            { text: ". Once the Coinsurance Maximum is reached, the plan will then pay 100% of the Allowable Amount for the remainder of the " },
            { field: { key: "period3", type: "select", options: PERIOD_OPTS, strikethrough: true } },
            { text: "." },
          ],
        },
        note: "** Be careful when quoting OON Coinsurance Max details; some plans have no OON Coinsurance Max, but pays at a coinsurance %.",
      };

    case "preventive":
      return {
        title: "Preventive",
        segments: [
          { text: "You're currently active and eligible on a " },
          { field: { key: "periodType", type: "select", options: PERIOD_OPTS } },
          { text: ". Your preventive care benefits are covered under the " },
          { field: { key: "network", type: "select", options: NETWORK_OPTS, strikethrough: true } },
          { text: " network at no cost sharing when using an in-network provider." },
        ],
      };
  }
}

// ─── Inline Field Renderer ────────────────────────────────────────────────────

interface FieldProps {
  field: ScriptField;
  value: string;
  onChange: (key: string, value: string) => void;
}

function FieldRenderer({ field, value, onChange }: FieldProps) {
  if (field.type === "static") {
    return (
      <span className="bsm-strike">Deductible</span>
    );
  }

  const content =
    field.type === "select" ? (
      <select
        className="bsm-inline-select"
        value={value}
        onChange={(e) => onChange(field.key, e.target.value)}
      >
        {(field.options ?? []).map((o) => (
          <option key={o}>{o}</option>
        ))}
      </select>
    ) : (
      <input
        className="bsm-inline-input"
        style={{ minWidth: field.width ?? 70 }}
        value={value}
        onChange={(e) => onChange(field.key, e.target.value)}
      />
    );

  if (field.strikethrough) {
    return (
      <span className="bsm-strike">
        {field.label && <span>{field.label}</span>}
        {content}
      </span>
    );
  }

  return <>{content}</>;
}

// ─── Dynamic Script Body ──────────────────────────────────────────────────────

interface ScriptBodyProps {
  template: ScriptTemplate;
  data: Record<string, string>;
  onChange: (key: string, value: string) => void;
}

function ScriptBody({ template, data, onChange }: ScriptBodyProps) {
  const renderSegments = (segments: ScriptSegment[]) =>
    segments.map((seg, i) => {
      if (seg.text) return <span key={i}>{seg.text}</span>;
      if (seg.field) {
        return (
          <FieldRenderer
            key={i}
            field={seg.field}
            value={data[seg.field.key] ?? ""}
            onChange={onChange}
          />
        );
      }
      return null;
    });

  return (
    <div className="bsm-script-body">
      {renderSegments(template.segments)}

      {template.conditional && (
        <div className="bsm-conditional">
          <div className="bsm-conditional-label">{template.conditional.label}</div>
          {renderSegments(template.conditional.segments)}
        </div>
      )}

      {template.note && (
        <div className="bsm-note">{template.note}</div>
      )}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function BenefitsScriptMapping() {
  const [selectedKey, setSelectedKey] = useState<DropdownKey>("deductible|inn");
  const [data, setData] = useState<DataStore>(initialData);
  const [toastVisible, setToastVisible] = useState(false);

  const selectedOption = DROPDOWN_OPTIONS.find((o) => o.value === selectedKey)!;
  const template = getTemplate(selectedOption.scriptKey);
  const currentData = data[selectedKey] ?? {};

  const handleFieldChange = useCallback(
    (key: string, value: string) => {
      setData((prev) => ({
        ...prev,
        [selectedKey]: { ...prev[selectedKey], [key]: value },
      }));
    },
    [selectedKey]
  );

  const handleCopy = () => {
    const el = document.querySelector("[data-script-body]") as HTMLElement | null;
    if (el) {
      navigator.clipboard.writeText(el.innerText.trim()).catch(() => {});
    }
    setToastVisible(true);
    setTimeout(() => setToastVisible(false), 2000);
  };

  return (
    <div className="bsm-wrapper">
      <div className="bsm-container">

        {/* Header */}
        <div className="bsm-header">
          <h1>Script field mapping</h1>
          <span>— benefits quoting tool</span>
        </div>

        {/* Scripts Dropdown */}
        <div className="bsm-dropdown-wrapper">
          <label className="bsm-dropdown-label">Scripts Dropdown</label>
          <select
            className="bsm-dropdown"
            value={selectedKey}
            onChange={(e) => setSelectedKey(e.target.value)}
          >
            {DROPDOWN_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>

        {/* Script Card */}
        <div className="bsm-card">
          <div className="bsm-card-header">
            <div style={{ flex: 1 }} />
            <div className="bsm-card-title">{template.title}</div>
            <div style={{ flex: 1, textAlign: "right" }}>
              <button className="bsm-copy-btn" onClick={handleCopy}>
                Copy script ↗
              </button>
            </div>
          </div>

          <div data-script-body>
            <ScriptBody
              template={template}
              data={currentData}
              onChange={handleFieldChange}
            />
          </div>
        </div>

      </div>

      {/* Toast */}
      <div className={`bsm-toast${toastVisible ? " visible" : ""}`}>
        Script copied to clipboard
      </div>
    </div>
  );
}
