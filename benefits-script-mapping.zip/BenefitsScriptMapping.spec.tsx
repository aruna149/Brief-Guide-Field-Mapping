import { render, screen, fireEvent } from "@testing-library/react";
import BenefitsScriptMapping from "./BenefitsScriptMapping";

// ─── Dropdown Tests ───────────────────────────────────────────────────────────

describe("Scripts Dropdown", () => {
  it("renders the dropdown with default selection", () => {
    render(<BenefitsScriptMapping />);
    const dropdown = screen.getByRole("combobox", { name: /scripts dropdown/i });
    expect(dropdown).toBeInTheDocument();
    expect((dropdown as HTMLSelectElement).value).toBe("deductible|inn");
  });

  it("renders all 10 dropdown options", () => {
    render(<BenefitsScriptMapping />);
    const dropdown = screen.getByRole("combobox", { name: /scripts dropdown/i });
    const options = (dropdown as HTMLSelectElement).options;
    expect(options.length).toBe(10);
  });

  it("changes script title when dropdown selection changes", () => {
    render(<BenefitsScriptMapping />);
    const dropdown = screen.getByRole("combobox", { name: /scripts dropdown/i });

    fireEvent.change(dropdown, { target: { value: "copay|inn" } });
    expect(screen.getByText("Copayment")).toBeInTheDocument();

    fireEvent.change(dropdown, { target: { value: "coinsurance|oon" } });
    expect(screen.getByText("Deductible/Coinsurance Maximum Plans")).toBeInTheDocument();

    fireEvent.change(dropdown, { target: { value: "preventive|inn" } });
    expect(screen.getByText("Preventive")).toBeInTheDocument();
  });
});

// ─── Script Content Tests ─────────────────────────────────────────────────────

describe("Script content", () => {
  it("shows Calendar Year / Plan Year select — no date picker", () => {
    render(<BenefitsScriptMapping />);
    // Should NOT find a date input
    const dateInput = document.querySelector('input[type="date"]');
    expect(dateInput).toBeNull();
  });

  it("renders period type as select with Calendar Year and Plan Year options", () => {
    render(<BenefitsScriptMapping />);
    // The inline period selects should have the two options
    const selects = document.querySelectorAll(".bsm-inline-select");
    const periodSelect = Array.from(selects).find((s) => {
      const opts = Array.from((s as HTMLSelectElement).options).map((o) => o.text);
      return opts.includes("Calendar Year") && opts.includes("Plan Year");
    });
    expect(periodSelect).toBeTruthy();
  });

  it("does NOT render member info bar", () => {
    render(<BenefitsScriptMapping />);
    expect(screen.queryByLabelText(/member id/i)).toBeNull();
    expect(screen.queryByLabelText(/group no/i)).toBeNull();
    expect(screen.queryByLabelText(/date of service/i)).toBeNull();
  });

  it("does NOT render summary cards", () => {
    render(<BenefitsScriptMapping />);
    expect(screen.queryByText(/remaining oop/i)).toBeNull();
    expect(screen.queryByText(/deductible paid/i)).toBeNull();
  });
});

// ─── Inline Field Tests ───────────────────────────────────────────────────────

describe("Inline field editing", () => {
  it("updates copay amount when user types", () => {
    render(<BenefitsScriptMapping />);
    fireEvent.change(
      screen.getByRole("combobox", { name: /scripts dropdown/i }),
      { target: { value: "copay|inn" } }
    );
    const inputs = document.querySelectorAll(".bsm-inline-input");
    const copayInput = inputs[0] as HTMLInputElement;
    fireEvent.change(copayInput, { target: { value: "35" } });
    expect(copayInput.value).toBe("35");
  });

  it("each dropdown key has isolated data — changing one does not affect another", () => {
    render(<BenefitsScriptMapping />);
    const dropdown = screen.getByRole("combobox", { name: /scripts dropdown/i });

    // Select copay INN and change a field
    fireEvent.change(dropdown, { target: { value: "copay|inn" } });
    const inputs = document.querySelectorAll(".bsm-inline-input");
    fireEvent.change(inputs[0] as HTMLInputElement, { target: { value: "99" } });

    // Switch to copay OON — value should be different
    fireEvent.change(dropdown, { target: { value: "copay|oon" } });
    const oonInputs = document.querySelectorAll(".bsm-inline-input");
    expect((oonInputs[0] as HTMLInputElement).value).not.toBe("99");
  });
});

// ─── Copy Script Tests ────────────────────────────────────────────────────────

describe("Copy script button", () => {
  it("renders copy button", () => {
    render(<BenefitsScriptMapping />);
    expect(screen.getByRole("button", { name: /copy script/i })).toBeInTheDocument();
  });
});
